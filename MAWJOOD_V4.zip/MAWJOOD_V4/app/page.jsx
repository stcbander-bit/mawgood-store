'use client';
import {useState} from 'react';
const products=[
 {id:1,n:'سماعة لاسلكية',c:'إلكترونيات',p:129,sa:12,cn:80,i:'🎧'},
 {id:2,n:'مصباح ذكي',c:'المنزل والمطبخ',p:89,sa:0,cn:45,i:'💡'},
 {id:3,n:'حامل جوال للسيارة',c:'السيارات',p:59,sa:18,cn:120,i:'🚗'},
 {id:4,n:'ساعة رياضية',c:'الرياضة',p:149,sa:4,cn:60,i:'⌚'},
 {id:5,n:'منظم مكتب',c:'المنزل والمطبخ',p:39,sa:7,cn:60,i:'🗂️'},
 {id:6,n:'لوحة مفاتيح',c:'الكمبيوتر',p:179,sa:0,cn:35,i:'⌨️'}
];
const cats=['الكل','إلكترونيات','المنزل والمطبخ','الأزياء','الجمال','السيارات','الأطفال','الرياضة','الألعاب','الكمبيوتر'];
export default function Home(){
 const [cat,setCat]=useState('الكل'),[cart,setCart]=useState([]);
 const list=cat==='الكل'?products:products.filter(x=>x.c===cat);
 const total=cart.reduce((s,x)=>s+x.p,0);
 return <><header><b>موجود | MAWJOOD</b><div><a href="/admin">لوحة الإدارة</a><button onClick={()=>alert(`السلة: ${cart.length} | الإجمالي: ${total} ر.س`)}>السلة ({cart.length})</button></div></header>
 <section className="hero"><h1>متجر واحد — مصادر متعددة</h1><p>منتجات متنوعة مع إدارة مخزون من السعودية والصين، وبنية جاهزة للدفع والشحن الحقيقي.</p></section>
 <main><div className="cats">{cats.map(c=><button className={cat===c?'active':''} onClick={()=>setCat(c)} key={c}>{c}</button>)}</div>
 <div className="grid">{list.map(p=><article className="card" key={p.id}><div className="pic">{p.i}</div><h3>{p.n}</h3><small>{p.c} · 🇸🇦 {p.sa} · 🇨🇳 {p.cn}</small><strong>{p.p} ر.س</strong><button onClick={()=>setCart([...cart,p])}>أضف للسلة</button></article>)}</div>
 <section className="panel"><h2>منطق تنفيذ الطلب</h2><p>السعودية أولًا عند توفر المخزون، ثم الصين عند عدم توفره. في المرحلة الإنتاجية يمكن اختيار المصدر حسب السعر أو سرعة الشحن.</p></section></main>
 <footer>MAWJOOD V4 — نسخة Online جاهزة للربط بالخدمات السحابية.</footer></>
}
