export default function Admin(){
return <main className="admin"><h1>لوحة إدارة MAWJOOD V4</h1>
<div className="stats"><div>الطلبات<strong>0</strong></div><div>المبيعات<strong>0 ر.س</strong></div><div>مخزون السعودية<strong>—</strong></div><div>مخزون الصين<strong>—</strong></div></div>
<section className="panel"><h2>الوحدات</h2><p>المنتجات · الطلبات · المخزون · المستودعات · الموردون · الشحن · العملاء · التقارير</p></section>
<section className="panel"><h2>حالة الربط</h2><p>قاعدة البيانات والدفع والشحن تحتاج مفاتيح الحسابات الحقيقية قبل التشغيل الإنتاجي.</p></section></main>
}