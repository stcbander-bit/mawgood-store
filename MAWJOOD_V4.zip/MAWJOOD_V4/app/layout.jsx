import './style.css';
export const metadata={title:'MAWJOOD | موجود',description:'متجر إلكتروني متعدد المستودعات'};
export default function RootLayout({children}){return <html lang="ar" dir="rtl"><body>{children}</body></html>}
